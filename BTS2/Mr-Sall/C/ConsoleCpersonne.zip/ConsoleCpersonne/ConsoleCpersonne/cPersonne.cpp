#include <iostream>
#include "cPersonne.h"

cPersonne::cPersonne(string nom, string prenom, int age)
{
	this->nom = nom; // utilisation du pointeur this : l'objet lui m�me
	this->prenom = prenom;
	this->age = age;
}

void cPersonne::afficher()
{
	cout << prenom << " " << nom << " " << age << " ans" << endl;
}