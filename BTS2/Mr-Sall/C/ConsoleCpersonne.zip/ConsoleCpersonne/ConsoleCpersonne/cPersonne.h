#pragma once
#ifndef CPERSONNE_H
#define CPERSONNE_H
#include <iostream>


using namespace std;
class cPersonne {
	private:
		string nom;
		string prenom;
		int age;
	public:
		cPersonne(string nom, string prenom, int age);
		void afficher();
};

#endif // !
